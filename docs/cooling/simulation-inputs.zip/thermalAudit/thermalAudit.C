#include "fvCFD.H"

int main(int argc, char *argv[])
{
    timeSelector::addOptions();
    argList::addBoolOption("solve", "Converge theta on the frozen velocity and turbulence field before auditing");
    #include "setRootCase.H"
    #include "createTime.H"
    instantList times = timeSelector::select0(runTime, args);
    #include "createMesh.H"
    forAll(times, ti)
    {
        runTime.setTime(times[ti], ti);
        mesh.readUpdate();
        volScalarField theta(IOobject("theta", runTime.timeName(), mesh, IOobject::MUST_READ, IOobject::NO_WRITE), mesh);
        volScalarField nut(IOobject("nut", runTime.timeName(), mesh, IOobject::MUST_READ, IOobject::NO_WRITE), mesh);
        surfaceScalarField phi(IOobject("phi", runTime.timeName(), mesh, IOobject::MUST_READ, IOobject::NO_WRITE), mesh);
        theta.correctBoundaryConditions();
        dimensionedScalar alpha("alpha", dimViscosity, 1.7e-5/0.71);
        surfaceScalarField alphaEff("alphaEff", alpha + fvc::interpolate(nut)/0.85);
        if (args.found("solve"))
        {
            dictionary solver;
            solver.add("solver", "PBiCGStab");
            solver.add("preconditioner", "DILU");
            solver.add("tolerance", 1e-10);
            solver.add("relTol", 0.001);
            solver.add("maxIter", 1000);
            for (label outer=0; outer<100; ++outer)
            {
                fvScalarMatrix eqn(fvm::div(phi, theta) - fvm::laplacian(alphaEff, theta));
                SolverPerformance<scalar> perf = eqn.solve(solver);
                Info << "Frozen-flow scalar iteration " << outer << " residual " << perf.initialResidual() << nl;
                if (perf.initialResidual()<1e-8) break;
            }
            theta.write();
        }
        surfaceScalarField diffusive("diffusive", alphaEff*fvc::snGrad(theta)*mesh.magSf());
        OFstream csv(runTime.path()/ ("thermal-audit-" + runTime.timeName() + ".csv"));
        csv.precision(12);
        csv << "patch,area_m2,volume_out_m3_s,advected_out_W_K,diffusive_in_W_K" << nl;
        scalar advTotal=0, diffTotal=0;
        forAll(mesh.boundary(), pi)
        {
            if (mesh.boundary()[pi].coupled()) continue;
            scalar area=gSum(mesh.magSf().boundaryField()[pi]);
            scalar vol=gSum(phi.boundaryField()[pi]);
            scalar adv=1.13*1006*gSum(phi.boundaryField()[pi]*theta.boundaryField()[pi]);
            scalar diff=1.13*1006*gSum(diffusive.boundaryField()[pi]);
            csv << mesh.boundary()[pi].name() << ',' << area << ',' << vol << ',' << adv << ',' << diff << nl;
            advTotal += adv; diffTotal += diff;
        }
        Info << "Thermal audit " << runTime.timeName() << " advected out=" << advTotal << " diffusive in=" << diffTotal << " residual=" << advTotal-diffTotal << nl;
    }
    return 0;
}
