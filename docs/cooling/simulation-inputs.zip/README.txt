Exploratory Rapido X cooling comparison input archive

Requirements: OpenFOAM v2412 runtime and development tools, C++ compiler,
MPI, Python 3 and NumPy. Source your OpenFOAM environment, extract to a
Linux filesystem, cd to this directory, and run: bash Allrun
Twelve ranks are used. Runtime and disk requirements are substantial.

STL coordinates are metres in the assembled frame. Geometry is already
registered and repaired. Mesh files and volume solution fields are not
included; Allrun rebuilds meshes and solves the six cases.

The published baseline was initially advanced using OpenFOAM v1912 and
continued with v2412 after a function-object compatibility issue. Allrun
uses v2412 from the start, so it is a configuration-level reproduction,
not a promise of bit-for-bit identical iteration history.

See the accompanying report for source repositories, transformations,
material/flow assumptions, mesh warnings and validation limitations.
The two baseline checkMesh runs each flag one high-skewness boundary
face. This warning is not hidden or treated as a complete mesh pass.

ThermalAudit converges a passive scalar on a frozen flow field. It is not
a conjugate solid/air heat-transfer solver. The 250/300 C block scenarios
are separate illustrative thermal-network calculations in the report.

Source geometry: Psych0h3ad/Rapido-X; VoronDesign/Voron-Stealthburner;
VoronDesign/VoronUsers (bythorsthunder/Stealthburner_Rapido_Uhf).
Source ownership and upstream licenses continue to apply.
