from pathlib import Path
import shutil,os,re,sys,math,json
import numpy as np
root=Path(os.environ['RAPIDO_CFD_ROOT']);base=sys.argv[1];pressure=float(sys.argv[2]);src=root/base;dst=root/f'{base}_{pressure:g}Pa'
if dst.exists():raise RuntimeError('Refusing to overwrite existing case '+str(dst))
dst.mkdir();shutil.copytree(src/'system',dst/'system');shutil.copytree(src/'constant',dst/'constant',copy_function=os.link)
factor=pressure/25.;scales={'U':math.sqrt(factor),'phi':math.sqrt(factor),'p':factor,'k':factor,'omega':math.sqrt(factor),'nut':math.sqrt(factor),'theta':1.}
def scaled(data,scale):
 if scale==1:return data
 token=rb'\b(?:internalField|value|inletValue|p0)\s+'
 rx=re.compile(token+rb'nonuniform\s+List<(scalar|vector)>\s+(\d+)\s*\(')
 out=bytearray(data);end=0
 while (m:=rx.search(data,end)) is not None:
  n=int(m[2])*(3 if m[1]==b'vector' else 1);start=m.end();end=start+8*n
  a=np.frombuffer(data,dtype='<f8',count=n,offset=start).copy();a*=scale;out[start:end]=a.tobytes()
 data=bytes(out)
 rx=re.compile(b'('+token+rb'uniform\s+)(\([^\)]*\)|[-+0-9.eE]+)(\s*;)')
 def replace(m):
  raw=m[2];vector=raw.startswith(b'(');nums=[float(x) for x in raw.strip(b'()').split()]
  text=b' '.join(f'{x*scale:.12g}'.encode() for x in nums)
  return m[1]+(b'('+text+b')' if vector else text)+m[3]
 return rx.sub(replace,data)
for proc in sorted(src.glob('processor*')):
 target=dst/proc.name;target.mkdir();shutil.copytree(proc/'constant',target/'constant',copy_function=os.link)
 latest=max((x for x in proc.iterdir() if x.is_dir() and re.fullmatch(r'[0-9.]+',x.name)),key=lambda x:float(x.name))
 (target/'0').mkdir()
 for field,s in scales.items():
  data=(latest/field).read_bytes();data=scaled(data,s)
  # The location is descriptive; writing it correctly also aids inspection.
  data=re.sub(rb'location\s+"[^"]*";',b'location "0";',data,count=1)
  (target/'0'/field).write_bytes(data)
shutil.copytree(src/'0',dst/'0')
for field,s in scales.items():
 p=dst/'0'/field
 if p.exists():p.write_bytes(scaled(p.read_bytes(),s))
p=dst/'system/controlDict';s=p.read_text();s=s.replace('startFrom latestTime','startFrom startTime')
s=re.sub(r'endTime\s+\d+;', 'endTime 120;', s);s=re.sub(r'writeControl timeStep; writeInterval \d+; purgeWrite', 'writeControl timeStep; writeInterval 120; purgeWrite',s)
p.write_text(s)
(dst/'initialization.json').write_text(json.dumps({'source':base,'pressure_Pa':pressure,'scaling_factors':scales,'note':'Warm start only; all transport equations are solved again.'},indent=2))
print(dst)
